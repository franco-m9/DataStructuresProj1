/*Franco Marcoccia
9/20/108
COP4530
This project stores the AS with neighboring ASes using data structures
*/
#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
#include <sstream>

using namespace std;

vector<string> split(const string &s, const char c);

bool SizeSort(const pair<int,vector<int> > &x, const pair<int,vector<int> > &y);

int main()
{
string line;
vector<pair<int, vector<int> > > node_vector;
vector<string> seven, temp, temp2;
vector<int> ints, temp3;
int numbers;
int inp=9;
		while(getline(cin,line))							// read one line at a time
		{
			temp = split(line,'|');							// calls split function to separate fields
			if(find(temp[6].begin(),temp[6].end(),'[') != temp[6].end())		// find function to throw away anything after '[' if it exists
			{
			temp2 = split(temp[6],'['); 
			seven.push_back(temp2[0]);
			}
			else
			seven.push_back(temp[6]);
												// at this point vector <string> seven has the 7th field with exceptions
			istringstream output(seven[0]);
			while(output>>numbers)
			ints.push_back(numbers);						// string is parsed into ints


			for(int i=0; i<ints.size(); i++)
			{	
			if(i<=0)
			{
				for(int j=0; j<node_vector.size();j++)
				{
					if(ints[i]==node_vector[j].first)								// if(find(node_vector.begin(),node_vector.end(),ints[i]))	
					{
						if(ints[i]!=ints[i+1])
						node_vector[j].second.push_back(ints[i+1]);						
						break;
					}
					else
					{
						if(ints[i]!=ints[i+1])
						{
						temp3.push_back(ints[i+1]);
						node_vector.push_back(make_pair(ints[i],temp3));
						temp3.clear();
						inp=9;
						}
					}
				}
			}
			else if(i>=ints.size()-1)
			{
				for(int j=0; j<node_vector.size();j++)
                                {       
                                        if(ints[i]==node_vector[j].first)
                                        {
                                        	if(ints[i]!=ints[i-1])
                                       	 	node_vector[j].second.push_back(ints[i-1]);
						inp=1;
						break;
                                        }
				}
 					if(inp!=1)
					{
                                        	if(ints[i]!=ints[i-1])
                                        	{
                                        	temp3.push_back(ints[i-1]);
                                        	node_vector.push_back(make_pair(ints[i],temp3));
						temp3.clear();
						inp=9;
						}
                                        }				
			}
			else
			{
				for(int j=0; j<node_vector.size();j++)
                                {       
                                        if(ints[i]==node_vector[j].first)        
                                        {
					if(ints[i]!=ints[i-1])
                                        node_vector[j].second.push_back(ints[i-1]);
					if(ints[i]!=ints[i+1])
					node_vector[j].second.push_back(ints[i+1]);
					inp=1;
                                        }
				}
                                	if(inp!=1)
                                        {
						if(ints[i]!=ints[i-1])
                                        	temp3.push_back(ints[i-1]);
						if(ints[i]!=ints[i+1])
						temp3.push_back(ints[i+1]);
                                        	node_vector.push_back(make_pair(ints[i],temp3));
						temp3.clear();
						inp=9;
                                        }
			}	
			} 
			temp.clear();                                                                   // clearing of vectors for next run
                        temp2.clear();
                        seven.clear();
                        ints.clear();
		}

                            
for(int i=0;i<node_vector.size();i++)									// sorts neighbors in ascending order
sort(node_vector[i].second.begin(),node_vector[i].second.end());

for(int i=0; i<node_vector.size();i++)									// deletes any duplicate neighbors that were inserted originally
node_vector[i].second.erase(unique(node_vector[i].second.begin(),node_vector[i].second.end()),node_vector[i].second.end());

sort(node_vector.begin(),node_vector.end(),SizeSort);

for(int i=0; i<node_vector.size();i++)									// displays in proper format
{
cout << node_vector[i].first << " ";				
cout << node_vector[i].second.size() << endl;
for(int j=0; j<node_vector[i].second.size();j++)
{
	if(j>=1)
	cout << "|";
cout << node_vector[i].second[j];
}
cout << endl;
}


return 0;
}

vector<string> split(const string &s, const char d)							// retrieved from r2 notes
{
string field;
vector<string> cut;

istringstream ss(s);

while (getline(ss, field, d))
	cut.push_back(field);

return cut;
}

bool SizeSort(const pair<int,vector<int> > &x, const pair<int,vector<int> > &y)
{
if(x.second.size()==y.second.size())
	return (x.first<y.first);
else if(x.second.size()!=y.second.size())
	return (x.second.size() > y.second.size());
}
